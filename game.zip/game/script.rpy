﻿# ==========================================================
#  MYBOBO 游戏  script.rpy （终极安全回退版）
# ==========================================================

init -1 python:
    # 强制框贴紧屏幕最底部
    gui.textbox_yalign = 1.0
    
    # 强制文字坐标：X=450 (避开名字框)，Y=90 (刚好在浅色框中间)
    gui.dialogue_xpos = 450
    gui.dialogue_ypos = 90
    gui.dialogue_width = 1200       # 限制文字宽度，防止太长顶到右边
    gui.dialogue_text_xalign = 0.0  # 文本左对齐

# ---------- BGM ----------
define audio.main_bgm = "TF家族-杨博文 - 百无聊赖.ogg"

# ---------- 数值 ----------
default courage    = 0
default bond       = 0
default went_crane = False

# ---------- 转场 ----------
define swipeleft = moveinright
define flash     = Fade(0.08, 0.0, 0.28, color="#ffffff")

# ==========================================================
#  各自独立的对话框背景（保留你的原图）
# ==========================================================
define BG_BM  = "images/哥哥对话框.png"
define BG_NM  = "images/妹妹对话框.png"
define BG_BO1 = "images/啵一对话框.png"
define BG_BO2 = "images/啵二对话框.png"
define BG_NAR = "images/旁白.png" 


# ==========================================================
#  立绘位置：最标准写法，右下角，缩小，压在框上
# ==========================================================
transform sprite_pos:
    xalign 0.85       # 靠右
    yalign 1.0        # 底部对齐
    yoffset -200      # 往上提，压在框上（如果觉得挡住文字了，把 -250 改成 -300）
    zoom 0.6          # 缩小立绘
    alpha 0.0
    ease 0.2 alpha 1.0

transform popup_tf:
    alpha 0.0
    yoffset 24
    ease 0.22 alpha 1.0 yoffset 0

transform blink_tf:
    alpha 0.35
    linear 1.0 alpha 1.0
    linear 1.0 alpha 0.35
    repeat


# ==========================================================
#  立绘自动显示 / 说完消失（恢复最纯净的逻辑）
# ==========================================================
init python:
    def sprite_cb(tag):
        def cb(event, interact=True, **kwargs):
            if not interact:
                return
            if event == "show":
                if renpy.has_image(tag):
                    renpy.show(tag, at_list=[sprite_pos])
            elif event == "slow_done":
                if renpy.has_image(tag):
                    renpy.hide(tag)
        return cb


# ==========================================================
#  角色定义
# ==========================================================
define bm  = Character("波米诺", what_color="#000000",
                       window_background=BG_BM,
                       callback=sprite_cb("波米诺"))

define nm  = Character("糯米啵", what_color="#000000",
                       window_background=BG_NM,
                       callback=sprite_cb("糯米啵"))

define bo1 = Character("啵一", what_color="#000000",
                       window_background=BG_BO1,
                       callback=sprite_cb("啵一"))

define bo2 = Character("啵二", what_color="#000000",
                       window_background=BG_BO2,
                       callback=sprite_cb("啵二"))

define narrator = Character(None, what_color="#000000",
                            window_background=BG_NAR)


# ==========================================================
#  【终极回退】最基础的排版，绝不乱飞，文字自动听 gui.rpy 的话待在框里
# ==========================================================
screen say(who, what):
    style_prefix "say"
    
    window:
        id "window"
        yalign 1.0  # 强制框贴屏幕最底部
        
        # 只改这一行：直接写死 XY 坐标
        # xpos 450: 避开左侧的名字框
        # ypos 80: 放进框内的垂直位置
        text what id "what" xpos 450 ypos 200
        
    use quick_menu


# ==========================================================
#  右上角数值面板
# ==========================================================
screen stats():
    zorder 100
    frame:
        xalign 0.99
        yalign 0.02
        padding (22, 14)
        background Solid("#00000099")
        vbox:
            spacing 8
            text "勇气  [courage]" size 42 color "#ffd166" outlines [(2, "#000000cc", 0, 0)]
            text "羁绊  [bond]"    size 42 color "#ff9ecb" outlines [(2, "#000000cc", 0, 0)]


# ==========================================================
#  数值变化飘字
# ==========================================================
screen stat_notify(msgs):
    zorder 200
    timer 1.6 action Hide("stat_notify")
    vbox:
        xalign 0.5
        yalign 0.38
        spacing 16
        for lab, d in msgs:
            text ("%s %s%d" % (lab, "+" if d > 0 else "", d)):
                xalign 0.5
                size 56
                color "#ffffff"
                outlines [(4, "#000000cc", 0, 0)]
                at popup_tf

init python:
    def add_stat(bond=0, courage=0):
        store.bond    += bond
        store.courage += courage
        msgs = []
        if courage:
            msgs.append(("勇气", courage))
        if bond:
            msgs.append(("羁绊", bond))
        if msgs:
            renpy.show_screen("stat_notify", msgs=msgs)


# ==========================================================
#  章节卡
# ==========================================================
screen chapter_card(img):
    zorder 150
    add Solid("#000000")
    add img
    button:
        xysize (config.screen_width, config.screen_height)
        background None
        action Return()
    text "点击继续":
        xalign 0.5
        yalign 0.94
        size 30
        color "#ffffffaa"
        at blink_tf


# ==========================================================
#  开始
# ==========================================================
label start:

    play music main_bgm fadein 1.0
    show screen stats

    # ========== 序章 ==========
    call screen chapter_card("序章")

    scene 乡村 with fade
    "风卷着粉草掠过屋前。波米诺按歪帽子，看向坐在行李箱上晃腿的妹妹。"
    bm "行李都带齐了吗？"
    nm "地图、干粮，还有哥哥，都带齐了！"
    bm "那就出发吧。去世界的尽头看看。"
    nm "好呀！只要和哥哥一起，去哪里都可以。"

    # ---------- 商人 ----------
    scene 商人 with swipeleft
    "昨天出门闲逛时，偶遇赶路的旅行商人，有一张东西从他身上掉落了。"
    "要捡起这张牛皮纸残卷吗？"

    menu:
        "①立刻上前捡起":
            $ add_stat(bond=1, courage=1)
        "②犹豫片刻，等风吹近再捡":
            $ add_stat(bond=1, courage=0)
        "③有点害怕，让哥哥去捡。":
            $ add_stat(bond=1, courage=-1)

    # ---------- 地图 ----------
    scene 点击地图 with swipeleft
    "这是一张残缺的牛皮纸古地图，只有“居所→山路→啵国”的局部残卷。"
    "点击地图上的【啵国】区域查看详情。"

    menu:
        "①啵国":
            scene 啵国介绍 with dissolve
            "一处藏在山谷盆地中的国度。"
            "这里居住着啵一、啵二，民风温和。"
            "遍地彩色矮屋，四季繁花。"
            "有童趣小学、温柔博物馆、大片游乐庭院。"
            "是荒原之外唯一能遇见新朋友的地方。"
        "②传说":
            scene 仙鹤传说 with dissolve
            "传说仙鹤会穿梭在波纹大陆的各个国度，为远方的旅人传递信件与祝福。"
            "有缘的探险者，在受伤或危难之时，有机会遇见仙鹤。"

    scene 乡村 with flash
    bm "原来……有这样一个地方。"
    nm "哥哥！我们去啵国看看好不好！"
    bm "好，那就去啵国。"
    "残卷被妹妹小心收进收纳袋，兄妹沿山路方向出发。"
    "准备正式踏上旅途。"
    "此刻你们的心情是？"

    menu:
        "①妹妹蹦蹦跳跳走在前":
            $ add_stat(bond=1, courage=2)
        "②哥哥回望旧屋，略有不舍":
            $ add_stat(bond=2, courage=-1)
        "③两人并肩安静前行。":
            $ add_stat(bond=3, courage=1)

    # ========== 第一章 ==========
    call screen chapter_card("第一章")
    scene 赏花 with fade
    "走了半日，两人走进一片花野。"
    "妹妹突然停下脚步，指着不远处草丛——那里闪着细碎银光。"
    nm "哥哥你看！那里有亮晶晶的东西！"
    "草丛里有亮晶晶的东西，要怎么做？"

    menu:
        "①先赶路":
            bm "先赶路，不要乱跑。"
            $ add_stat(bond=1, courage=-1)
        "②就看一眼":
            nm "就看一眼，很快的！"
            $ add_stat(bond=2, courage=1)
        "③两人一起上前查看。":
            $ add_stat(bond=1, courage=2)

    "哥妹凑近发现是一颗漂亮的粉色爱心石头，妹妹收入小包。"
    "或许是给新朋友的一份见面礼。"

    # ========== 第二章 ==========
    call screen chapter_card("第二章")
    scene 森林 with dissolve
    "刚走进林间深处，树丛里突然窜出几只黑影，围着脚边打转，直盯着妹妹手里的干粮袋。"
    "小动物围住干粮，虎视眈眈！"
    with hpunch
    scene 动物袭击 with dissolve

    menu:
        "①退让分粮，平安离开":
            $ add_stat(bond=2, courage=-1)
            $ went_crane = False
            jump chapter4_walk
        "②死守唯一干粮，发生冲突受伤":
            $ add_stat(bond=1, courage=1)
            $ went_crane = True
            jump chapter3
        "③妹妹勇敢保护粮食，发生冲突受伤":
            $ add_stat(bond=3, courage=2)
            $ went_crane = True
            jump chapter3

    # ========== 第三章 ==========
label chapter3:
    call screen chapter_card("第三章")
    scene 仙鹤救援 with fade
    "受伤瞬间，远处天际一道白色身影俯冲而来——"
    "正是残卷背面「仙鹤传说」里写的灵鹤。"
    "波米诺瞪大双眼，糯米啵小声惊呼。"
    "仙鹤轻轻叼住兄妹衣领，带他们离开冲突现场，落在安全空地，衔来药草放在哥哥手边。"
    "伤口被温柔治愈，此刻心里的想法是？"

    menu:
        "①哥哥轻声安抚妹妹":
            bm "疼就说出来，别忍着。"
            nm "有哥哥和仙鹤在，不疼。"
            $ add_stat(bond=2, courage=1)
        "②妹妹有点动摇，害怕前路":
            nm "我们还要继续往前走吗？"
            bm "你想去，我们就去。"
            $ add_stat(bond=3, courage=-1)
        "③拿出干粮温柔投喂仙鹤":
            "妹妹分干粮喂仙鹤，仙鹤蹭她手心。"
            $ add_stat(bond=1, courage=2)

    # ========== 第四章 ==========
    call screen chapter_card("第四章")
    scene 仙鹤救援 with dissolve
    "伤势痊愈后，仙鹤驮着两人飞上天空。"
    "风从耳边吹过，仙鹤低鸣，下方那片粉墙黛瓦的盆地小国，就是残卷上记载的啵国。"
    jump chapter4_common

label chapter4_walk:
    call screen chapter_card("跳过仙鹤线")
    scene 啵国花海 with fade
    "二人一路徒步翻过丘陵，走了许久，终于在远方盆地看见了残卷上描绘的啵国。"
    jump chapter4_common

label chapter4_common:
    "看着远方的啵国，心中所想："

    menu:
        "①超级期待，迫不及待！":
            $ add_stat(bond=1, courage=2)
        "②陌生地方，谨慎一点":
            $ add_stat(bond=2, courage=-1)
        "③默默陪伴，静静向往。":
            $ add_stat(bond=3, courage=1)

    # ========== 第五章 ==========
    call screen chapter_card("第五章")
    scene 啵国花海 with fade

    if went_crane:
        "仙鹤轻轻落地，兄妹从鹤背上滑下来。"
    else:
        "兄妹走到草坪停下。"

    "不远处浆果丛里，啵一和啵二本来在采浆果。"
    "听见动静，他们猛地回头，看见陌生人，立刻躲回丛后。"
    bo2 "他们是谁呀……"
    bo1 "不知道……会不会是坏人……"
    "啵一啵二小声嘀咕的声音让妹妹发现了，妹妹摇了摇哥哥的衣袖往哥哥身后缩。"
    "面对躲起来的两个新朋友，要怎么做？"

    menu:
        "①勇敢主动上前打招呼":
            "妹妹从哥哥身后走出来挥手。"
            nm "你们好！我们不是坏人！"
            "她掏出准备好的粉色爱心石头礼物。"
            $ add_stat(bond=1, courage=3)
        "②害羞谨慎，慢慢靠近":
            "两人放慢脚步走过去，哥哥抬手示意没有恶意。"
            $ add_stat(bond=2, courage=1)
        "③太陌生了，想原路回家":
            "妹妹往哥哥身后缩。"
            nm "哥哥……我们回家吧……"
            $ add_stat(bond=1, courage=-4)

    jump endings


# ==========================================================
#  结局
# ==========================================================
label endings:
    if bond >= 12 and courage >= 10:
        jump ending_1
    elif bond >= 12 and courage < 10:
        jump ending_2
    else:
        jump ending_3

label ending_1:
    scene 仙鹤救援 with fade
    "夕阳把天空染成橘粉色，仙鹤在头顶盘旋一圈准备离开。"
    nm "哥哥，我们可以留下来吗？"
    "哥哥看着妹妹眼里的光，又看看温柔笑着的啵一，轻轻点头。"
    "从此荒原孤童有了新家和伙伴，四个小家伙每天一起采浆果、看小溪、在粉花海里奔跑，仙鹤偶尔飞来看看他们，日子温柔圆满。"
    scene 结局1 with fade
    "—— 结局1 · 圆满HE 「你好，新朋友」 ——"
    jump the_end

label ending_2:
    "哥妹还是留在了啵国，但依旧有些胆怯。"
    "他们在边境地带亲手搭起一间属于自己的简易木屋。"
    "内心仍带着荒原生活留下的胆怯，不会频繁去到啵国中心。"
    "每天牵手出门采花，遇到啵一啵二会害羞打招呼。"
    "啵一啵二也不着急，每天带浆果和小玩具来找他们，慢慢陪着两人熟悉这片土地。"
    "日子很慢很暖，旅途伤痕在温柔里一点点消散。"
    scene 结局2 with fade
    "—— 结局2 · 温柔慢热HE 「细水长流」 ——"
    jump the_end

label ending_3:
    "兄妹羁绊尚未累积到足以全然拥抱新世界的程度。"
    "啵一将一间闲置访客小屋借给他们暂住。"
    "这里可以遮风挡雨，却终究不是属于兄妹二人的家。"
    "他们感受着啵国的美好，却无法下定决心长久扎根。"
    "去或是留都没有答案，故事就此搁置，等待未来再做抉择。"
    scene 结局3 with fade
    "—— 留白结局 「等待未来」 ——"
    jump the_end

label the_end:
    "……"
    return